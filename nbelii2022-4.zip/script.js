$(function () {
    var squares = [], 
        SIZE = 3,
        EMPTY = "&nbsp;",
        score,
        moves,
        turn = "X",
        wins = [7, 56, 448, 73, 146, 292, 273, 84];

    /*
     * Resets the game board, score, and turn.
     */
    function startNewGame() {
        turn = "X";
        score = {"X": 0, "O": 0};
        moves = 0;
        squares.forEach(function (square) {
            square.html(EMPTY).removeClass("X O"); // Clear cell and remove classes
        });
        $("#game-status").text("Player X's turn"); // Initial game status message
    }

    /*
     * Checks if the given score matches any winning condition.
     */
    function win(score) {
        return wins.some(function(winPattern) { // Standard function to avoid arrow syntax issues
            return (winPattern & score) === winPattern;
        });
    }

    /*
     * Updates the board when a cell is clicked, checks for win/tie, and toggles turn.
     */
    function set() {
        if ($(this).html() !== EMPTY) {
            return; // Ignore clicks on filled cells
        }

        // Set the cell content to the current player's mark and apply the class
        $(this).html(turn).addClass(turn);
        moves += 1;
        score[turn] += $(this)[0].indicator;

        // Check for a win or a tie
        if (win(score[turn])) {
            $("#game-status").text(`Player ${turn} wins!`);
            setTimeout(startNewGame, 2000); // Delay before starting a new game
        } else if (moves === SIZE * SIZE) {
            $("#game-status").text("It's a tie!");
            setTimeout(startNewGame, 2000); // Delay before starting a new game
        } else {
            turn = turn === "X" ? "O" : "X"; // Toggle the turn
            $("#game-status").text(`Player ${turn}'s turn`);
        }
    }

    /*
     * Creates the game board, assigns indicators, and initializes the game.
     */
    function play() {
        var board = $("<table border=0 cellspacing=0>"), indicator = 1;
        for (var i = 0; i < SIZE; i += 1) {
            var row = $("<tr>");
            board.append(row);
            for (var j = 0; j < SIZE; j += 1) {
                var cell = $("<td align=center valign=center></td>");
                cell[0].indicator = indicator; // Unique indicator for each cell
                cell.click(set); // Attach click handler
                row.append(cell);
                squares.push(cell);
                indicator += indicator; // Update indicator by power of 2
            }
        }
        // Attach board to the #tictactoe div
        $("#tictactoe").append(board);
        startNewGame();
    }

    play(); // Start the game
});
