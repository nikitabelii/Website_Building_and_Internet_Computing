// Function to calculate the statistical values based on three input numbers
function calculateStats() {
    // Get the values entered by the user from the form
    const num1 = parseFloat(document.getElementById("num1").value);  // First number
    const num2 = parseFloat(document.getElementById("num2").value);  // Second number
    const num3 = parseFloat(document.getElementById("num3").value);  // Third number

    // Validate that all inputs are numbers
    if (isNaN(num1) || isNaN(num2) || isNaN(num3)) {
        alert("Please enter all three numbers.");  // Show an alert if any of the inputs are invalid
        return;  // Stop further execution if input is invalid
    }

    // Create an array to store the three numbers
    let numbers = [num1, num2, num3];

    // Sort the numbers in ascending order to help with median calculation
    numbers.sort((a, b) => a - b);

    // Calculate the maximum number
    const max = Math.max(...numbers);

    // Calculate the minimum number
    const min = Math.min(...numbers);

    // Calculate the mean (average) of the three numbers
    const mean = (num1 + num2 + num3) / 3;

    // Since the array is sorted, the median will always be the second number in a 3-number set
    const median = numbers[1];

    // Calculate the range (max - min)
    const range = max - min;

    // Display the calculated values
    document.getElementById("maxResult").innerText = max;      // Display max
    document.getElementById("minResult").innerText = min;      // Display min
    document.getElementById("meanResult").innerText = mean.toFixed(2);  // Display mean, rounded to 2 decimal places
    document.getElementById("medianResult").innerText = median;  // Display median
    document.getElementById("rangeResult").innerText = range;    // Display range
}
